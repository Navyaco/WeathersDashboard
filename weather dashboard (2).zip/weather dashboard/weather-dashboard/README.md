# Weather Dashboard

A modern weather dashboard application built with React, TypeScript, and Tailwind CSS. This application allows users to search for weather information by city name and displays current weather conditions in a clean, user-friendly interface.

## Features

- Search weather by city name
- Display current temperature in Celsius
- Show weather conditions with icons
- Display humidity, wind speed, and cloud coverage
- Dark mode support
- Responsive design

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file in the root directory and add your OpenWeather API key:
   ```
   VITE_OPENWEATHER_API_KEY=your_api_key_here
   ```

### Development

To start the development server:

```bash
npm run dev
```

### Building for Production

To create a production build:

```bash
npm run build
```

To preview the production build:

```bash
npm run preview
```

## Technologies Used

- React
- TypeScript
- Tailwind CSS
- Vite
- OpenWeather API
- Lucide Icons

## License

This project is licensed under the MIT License. 