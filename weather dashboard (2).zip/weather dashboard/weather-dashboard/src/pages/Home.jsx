import React, { useState, useEffect } from 'react'
import { useClimateData } from '../hooks/useClimateData'
import { ClimateDisplay } from '../components/ClimateDisplay'
import { Search, Moon, Sun, RefreshCw, X } from 'lucide-react'

export default function Home() {
  // State for search input and history
  const [city, setCity] = useState('')
  // Load search history from localStorage or start empty
  const [history, setHistory] = useState(() => {
    const saved = localStorage.getItem('searchHistory')
    return saved ? JSON.parse(saved) : []
  })
  // Load theme preference from localStorage or default to dark
  const [isDark, setIsDark] = useState(() => {
    const saved = localStorage.getItem('theme')
    return saved ? saved === 'dark' : true
  })
  const { climateData, error, loading, getClimateInfo } = useClimateData()

  // Persist search history and theme preference
  useEffect(() => {
    localStorage.setItem('searchHistory', JSON.stringify(history))
  }, [history])

  // Update theme class and save preference
  useEffect(() => {
    localStorage.setItem('theme', isDark ? 'dark' : 'light')
    document.documentElement.classList.toggle('light-theme', !isDark)
  }, [isDark])

  // Handle city search submission
  const handleSubmit = (e) => {
    e.preventDefault()
    if (!city.trim()) return
    getClimateInfo(city)
    // Add to history if not already present
    if (!history.includes(city)) {
      setHistory(prev => [city, ...prev].slice(0, 5)) // Keep last 5 searches
    }
    setCity('')
  }

  // Load weather data for a city from history
  const handleHistoryClick = (oldCity) => {
    getClimateInfo(oldCity)
  }

  // Clear search history from state and storage
  const clearHistory = () => {
    setHistory([])
  }

  // Refresh current city's weather data
  const refreshWeather = () => {
    if (climateData) {
      getClimateInfo(climateData.name)
    }
  }

  return (
    <div className="container">
      <div className="header">
        <h1>Weather Dashboard</h1>
        {/* Theme toggle button */}
        <button 
          onClick={() => setIsDark(prev => !prev)}
          className="theme-toggle"
          aria-label="Toggle theme"
        >
          {isDark ? <Sun /> : <Moon />}
        </button>
      </div>

      {/* Search form */}
      <form className="search-form" onSubmit={handleSubmit}>
        <div className="search-container">
          <Search className="search-icon" />
          <input
            type="text"
            value={city}
            onChange={e => setCity(e.target.value)}
            placeholder="Enter city name..."
            className="search-input"
          />
          <button type="submit" className="search-button">
            Search
          </button>
        </div>
      </form>

      {/* Recent searches section */}
      {history.length > 0 && (
        <div className="search-history">
          <div className="search-history-header">
            <h3>Recent Searches</h3>
            <button 
              onClick={clearHistory}
              className="clear-history"
              aria-label="Clear search history"
            >
              <X />
            </button>
          </div>
          <div className="search-history-list">
            {history.map((item, index) => (
              <button
                key={index}
                onClick={() => handleHistoryClick(item)}
                className="history-item"
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Conditional rendering based on loading/error state */}
      {loading ? (
        <div className="loading">
          <div className="loading-circle" />
          <p>Fetching weather data...</p>
        </div>
      ) : error ? (
        <div className="error-alert">
          <Search className="error-icon" />
          <p>{error}</p>
        </div>
      ) : climateData && (
        <div className="weather-wrapper">
          <button 
            onClick={refreshWeather}
            className="refresh-button"
            aria-label="Refresh weather data"
          >
            <RefreshCw />
          </button>
          <ClimateDisplay climateData={climateData} />
        </div>
      )}
    </div>
  )
} 