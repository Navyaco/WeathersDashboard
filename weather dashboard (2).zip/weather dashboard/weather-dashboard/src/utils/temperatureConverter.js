export function convertToCelsius(kelvinTemp) {
  return Math.round(kelvinTemp - 273.15);
}

export function convertToFahrenheit(celsiusTemp) {
  return Math.round((celsiusTemp * 9/5) + 32);
} 