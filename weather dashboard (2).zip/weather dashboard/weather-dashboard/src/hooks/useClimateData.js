import { useState } from 'react';

// Get API key from environment variables
const API_KEY = import.meta.env.VITE_WEATHER_API_KEY;
const BASE_URL = 'https://api.openweathermap.org/data/2.5/weather';

export function useClimateData() {
  // Track weather data, loading state, and errors
  const [climateData, setClimateData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const getClimateInfo = async (city) => {
    // Validate API key before making request
    if (!API_KEY) {
      setError('API key is missing. Please check your .env file.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      // Handle special characters in city names
      const encodedCity = encodeURIComponent(city.trim());
      const response = await fetch(
        `${BASE_URL}?q=${encodedCity}&appid=${API_KEY}&units=metric`
      );
      
      // Handle API response errors
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('City not found. Please check the spelling and try again.');
        }
        throw new Error('Failed to fetch weather data. Please try again later.');
      }
      
      const data = await response.json();
      setClimateData(data);
    } catch (err) {
      setError(err.message);
      setClimateData(null);
    } finally {
      setLoading(false);
    }
  };

  return { climateData, error, loading, getClimateInfo };
} 