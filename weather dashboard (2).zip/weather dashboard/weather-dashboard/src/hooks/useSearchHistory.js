import { useState, useEffect } from 'react';

const MAX_HISTORY = 5;
const STORAGE_KEY = 'weatherSearchHistory';

export function useSearchHistory() {
  const [history, setHistory] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  }, [history]);

  const addToHistory = (city) => {
    setHistory(prev => {
      const filtered = prev.filter(item => item !== city);
      return [city, ...filtered].slice(0, MAX_HISTORY);
    });
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return {
    history,
    addToHistory,
    clearHistory
  };
} 