import { useState, useEffect } from 'react'
import { useClimateData } from '../hooks/useClimateData'
import ClimateDisplay from './ClimateDisplay'
import SearchHistory from './SearchHistory'
import { FiSun, FiMoon, FiSearch, FiRefreshCw } from 'react-icons/fi'

export default function Home() {
  const [city, setCity] = useState('')
  const [isDark, setIsDark] = useState(false)
  const [history, setHistory] = useState([])
  const { weather, error, loading, getWeather } = useClimateData()

  useEffect(() => {
    if (isDark) {
      document.documentElement.setAttribute('data-theme', 'dark')
    } else {
      document.documentElement.removeAttribute('data-theme')
    }
  }, [isDark])

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!city.trim()) return

    getWeather(city)
    if (!history.includes(city)) {
      setHistory(prev => [city, ...prev].slice(0, 5))
    }
    setCity('')
  }

  const handleHistoryClick = (oldCity) => {
    getWeather(oldCity)
  }

  const refreshWeather = () => {
    if (weather?.name) {
      getWeather(weather.name)
    }
  }

  return (
    <div className="container">
      <header className="header">
        <h1>Weather Buddy 🌤️</h1>
        <button 
          className="btn"
          onClick={() => setIsDark(!isDark)}
          aria-label="Toggle theme"
        >
          {isDark ? <FiSun /> : <FiMoon />}
        </button>
      </header>

      <form className="search" onSubmit={handleSubmit}>
        <div className="search-wrap">
          <FiSearch className="search-icon" />
          <input
            type="text"
            value={city}
            onChange={e => setCity(e.target.value)}
            placeholder="Enter a city name..."
            aria-label="Search for a city"
          />
          <button type="submit" className="search-btn">
            Search
          </button>
        </div>
      </form>

      {loading ? (
        <div className="loading">
          <div className="loading-circle" />
          <div className="loading-content">
            <div className="loading-line" />
            <div className="loading-line" />
          </div>
        </div>
      ) : error ? (
        <div className="error">
          <FiSearch />
          <p>Oops! {error} 🌧️</p>
        </div>
      ) : weather && (
        <>
          <div style={{ position: 'relative' }}>
            <ClimateDisplay weather={weather} />
            <button 
              className={`btn ${loading ? 'spin' : ''}`}
              onClick={refreshWeather}
              style={{ position: 'absolute', top: '1rem', right: '1rem' }}
              aria-label="Refresh weather"
            >
              <FiRefreshCw />
            </button>
          </div>
          <SearchHistory 
            cities={history} 
            onCityClick={handleHistoryClick} 
          />
        </>
      )}
    </div>
  )
} 