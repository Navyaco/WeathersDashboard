import React, { useState } from 'react';
import { FiSearch } from 'react-icons/fi';

export function LocationSearch({ onLocationSearch }) {
  const [location, setLocation] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!location.trim()) return;
    onLocationSearch(location);
    setLocation('');
  };

  return (
    <form className="search" onSubmit={handleSubmit}>
      <div className="search-wrap">
        <FiSearch className="search-icon" />
        <input
          type="text"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          placeholder="Enter a city name..."
          aria-label="Search for a city"
        />
        <button type="submit" className="search-btn">
          Search
        </button>
      </div>
    </form>
  );
} 