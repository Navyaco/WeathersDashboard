import React from 'react';
import { Cloud, Thermometer, Wind, Droplets } from 'lucide-react';

export function ClimateDisplay({ climateData }) {
  // Don't render if no data is available
  if (!climateData) return null;

  // Extract and format weather data
  const temp = Math.round(climateData.main.temp);
  const description = climateData.weather[0].description;
  const humidity = climateData.main.humidity;
  // Convert wind speed from m/s to km/h
  const windSpeed = Math.round(climateData.wind.speed * 3.6);
  const clouds = climateData.clouds.all;
  
  // Get weather icon from OpenWeatherMap
  const iconCode = climateData.weather[0].icon;
  const iconUrl = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;
  const lastUpdate = new Date().toLocaleTimeString();

  return (
    <div className="weather-card">
      {/* City name and current conditions */}
      <div className="city-name">
        <h2>{climateData.name}</h2>
        <img 
          src={iconUrl} 
          alt={description}
          className="weather-main-icon"
        />
        <span className="weather-tag">{description}</span>
      </div>
      
      {/* Weather metrics grid */}
      <div className="weather-grid">
        {/* Temperature */}
        <div className="weather-item">
          <Thermometer className="weather-icon" />
          <h3>TEMPERATURE</h3>
          <p>{temp}°C</p>
        </div>
        
        {/* Humidity */}
        <div className="weather-item">
          <Droplets className="weather-icon" />
          <h3>HUMIDITY</h3>
          <p>{humidity}%</p>
        </div>
        
        {/* Wind Speed */}
        <div className="weather-item">
          <Wind className="weather-icon" />
          <h3>WIND SPEED</h3>
          <p>{windSpeed} km/h</p>
        </div>
        
        {/* Cloud Coverage */}
        <div className="weather-item">
          <Cloud className="weather-icon" />
          <h3>CLOUD COVER</h3>
          <p>{clouds}%</p>
        </div>
      </div>
      
      <div className="weather-footer">
        <p>Last updated: {lastUpdate}</p>
      </div>
    </div>
  );
} 