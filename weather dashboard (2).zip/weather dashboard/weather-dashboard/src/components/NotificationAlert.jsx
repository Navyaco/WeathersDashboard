import React from 'react';
import { FiAlertCircle } from 'react-icons/fi';

export function NotificationAlert({ alertMessage }) {
  if (!alertMessage) return null;

  return (
    <div className="error">
      <FiAlertCircle />
      <p>{alertMessage}</p>
    </div>
  );
} 