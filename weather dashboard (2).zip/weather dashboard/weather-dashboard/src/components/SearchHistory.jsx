import React from 'react';
import { History, X } from 'lucide-react';

export default function SearchHistory({ cities, onCityClick }) {
  if (!cities?.length) return null;

  return (
    <div className="search-history">
      <div className="search-history-header">
        <div className="search-history-title">
          <History className="search-history-icon" />
          <span>Recent Searches</span>
        </div>
      </div>
      <div className="search-history-list">
        {cities.map((city, index) => (
          <button
            key={`${city}-${index}`}
            onClick={() => onCityClick(city)}
            className="search-history-item"
          >
            {city}
          </button>
        ))}
      </div>
    </div>
  );
} 